/* 
Bienvenido al curso de Administración de MySQL: Seguridad y optimización de la base de datos. 

Te invito a preparar el ambiente para iniciar con nuestro entrenamiento. ¡Éxitos!
*/
