# 1838-administracion-de-mysql-parte-1

En este notebook encontrarás los comandos utilizados en el desarrollo del curso de Administración de MySQL: Seguridad y optimización de la base de datos.
